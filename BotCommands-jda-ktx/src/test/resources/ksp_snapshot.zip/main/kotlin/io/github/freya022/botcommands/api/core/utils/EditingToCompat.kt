@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.entities.Message
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel
import net.dv8tion.jda.api.interactions.InteractionHook
import net.dv8tion.jda.api.interactions.callbacks.IMessageEditCallback
import net.dv8tion.jda.api.requests.restaction.MessageEditAction
import net.dv8tion.jda.api.requests.restaction.WebhookMessageEditAction
import net.dv8tion.jda.api.requests.restaction.interactions.MessageEditCallbackAction
import net.dv8tion.jda.api.utils.messages.MessageEditData

import dev.freya02.botcommands.jda.ktx.messages.edit as edit_

/**
 * @see IMessageEditCallback.editMessage
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.edit\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.edit"
)
fun MessageEditData.edit(callback: IMessageEditCallback): MessageEditCallbackAction {
    return edit_(callback = callback)
}

/**
 * @see InteractionHook.editOriginal
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.edit\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.edit"
)
fun MessageEditData.edit(hook: InteractionHook): WebhookMessageEditAction<Message> {
    return edit_(hook = hook)
}

/**
 * @see MessageChannel.editMessageById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.edit\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.edit"
)
fun MessageEditData.edit(channel: MessageChannel, id: Long): MessageEditAction {
    return edit_(channel = channel, id = id)
}
