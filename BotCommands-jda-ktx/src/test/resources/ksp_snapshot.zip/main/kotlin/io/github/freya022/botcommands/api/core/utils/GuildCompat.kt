@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import dev.freya02.botcommands.jda.ktx.IgnoreForMatch
import dev.freya02.botcommands.jda.ktx.coroutines.await
import dev.freya02.botcommands.jda.ktx.deferredRestAction
import dev.freya02.botcommands.jda.ktx.requests.awaitCatching
import dev.freya02.botcommands.jda.ktx.requests.awaitOrNullOn
import dev.freya02.botcommands.jda.ktx.requests.onErrorResponseException
import dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponseOrNull
import net.dv8tion.jda.api.entities.*
import net.dv8tion.jda.api.entities.Guild.Ban
import net.dv8tion.jda.api.entities.automod.AutoModRule
import net.dv8tion.jda.api.entities.channel.ChannelType
import net.dv8tion.jda.api.entities.channel.concrete.ThreadChannel
import net.dv8tion.jda.api.entities.emoji.CustomEmoji
import net.dv8tion.jda.api.entities.emoji.RichCustomEmoji
import net.dv8tion.jda.api.entities.sticker.GuildSticker
import net.dv8tion.jda.api.entities.sticker.StickerSnowflake
import net.dv8tion.jda.api.requests.ErrorResponse
import net.dv8tion.jda.api.requests.RestAction
import net.dv8tion.jda.api.requests.Route
import net.dv8tion.jda.api.requests.restaction.CacheRestAction
import net.dv8tion.jda.api.utils.MiscUtil
import net.dv8tion.jda.internal.JDAImpl
import net.dv8tion.jda.internal.entities.GuildImpl
import net.dv8tion.jda.internal.requests.RestActionImpl

import dev.freya02.botcommands.jda.ktx.retrieve.retrieveMemberByIdOrNull as retrieveMemberByIdOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveMemberOrNull as retrieveMemberOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveBanOrNull as retrieveBanOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveVanityInviteOrNull as retrieveVanityInviteOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveThreadChannelById as retrieveThreadChannelById_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveThreadChannelOrNull as retrieveThreadChannelOrNull_

/**
 * Retrieves a [Member] with the provided ID.
 *
 * Throws the same exceptions as [Guild.retrieveMemberById],
 * minus [ErrorResponse.UNKNOWN_MEMBER] and [ErrorResponse.UNKNOWN_USER].
 *
 * @param userId   The ID of the member to retrieve
 * @param useCache Whether this should rely on the cache, set to `false` to always make a request.
 *
 * @see Guild.retrieveMemberById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveMemberByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveMemberByIdOrNull"
)
suspend fun Guild.retrieveMemberByIdOrNull(userId: String, useCache: Boolean): Member? {
    return retrieveMemberByIdOrNull_(userId = userId, useCache = useCache)
}

/**
 * Retrieves a [Member] with the provided ID.
 *
 * Throws the same exceptions as [Guild.retrieveMemberById],
 * minus [ErrorResponse.UNKNOWN_MEMBER] and [ErrorResponse.UNKNOWN_USER].
 *
 * @param userId   The ID of the member to retrieve
 * @param useCache Whether this should rely on the cache, set to `false` to always make a request.
 *
 * @see Guild.retrieveMemberById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveMemberByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveMemberByIdOrNull"
)
suspend fun Guild.retrieveMemberByIdOrNull(userId: Long, useCache: Boolean): Member? {
    return retrieveMemberByIdOrNull_(userId = userId, useCache = useCache)
}

/**
 * Retrieves a [Member] with the provided [User].
 *
 * Throws the same exceptions as [Guild.retrieveMember],
 * minus [ErrorResponse.UNKNOWN_MEMBER] and [ErrorResponse.UNKNOWN_USER].
 *
 * @param user     The user to retrieve the member for
 * @param useCache Whether this should rely on the cache, set to `false` to always make a request.
 *
 * @see Guild.retrieveMember
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveMemberOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveMemberOrNull"
)
suspend fun Guild.retrieveMemberOrNull(user: UserSnowflake, useCache: Boolean): Member? {
    return retrieveMemberOrNull_(user = user, useCache = useCache)
}

/**
 * Retrieves a [Ban] of the provided [UserSnowflake], or `null` if the user is not banned.
 *
 * Throws the same exceptions as [Guild.retrieveBan], minus [ErrorResponse.UNKNOWN_BAN].
 *
 * @see Guild.retrieveBan
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveBanOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveBanOrNull"
)
suspend fun Guild.retrieveBanOrNull(user: UserSnowflake): Ban? {
    return retrieveBanOrNull_(user = user)
}

/**
 * Retrieves the Vanity Invite meta-data for this guild,
 * or `null` if the vanity code is `null` or when a `INVITE_CODE_INVALID` error response was caught.
 *
 * Throws the same exceptions as [Guild.retrieveVanityInvite], minus [ErrorResponse.INVITE_CODE_INVALID].
 *
 * @see Guild.retrieveVanityInvite
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveVanityInviteOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveVanityInviteOrNull"
)
suspend fun Guild.retrieveVanityInviteOrNull(): VanityInvite? {
    return retrieveVanityInviteOrNull_()
}

/**
 * Retrieves a thread by ID.
 *
 * The cached threads are checked first, and then a request is made.
 *
 * The [RestAction] may throw [InvalidChannelTypeException] if a channel with the ID was found, but isn't a thread.
 *
 * @see retrieveThreadChannelOrNull
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveThreadChannelById\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveThreadChannelById"
)
fun Guild.retrieveThreadChannelById(id: Long): CacheRestAction<ThreadChannel> {
    return retrieveThreadChannelById_(id = id)
}

/**
 * Retrieves a thread by ID.
 *
 * The cached threads are checked first, and then a request is made.
 *
 * The returned thread may be null if:
 * - It doesn't exist
 * - The bot doesn't have access to it
 * - The channel isn't a thread
 *
 * @see retrieveThreadChannelById
 */
@Deprecated(message = "Replaced by retrieveThreadChannelByIdOrNull")
@Suppress(names = ["deprecated"])
suspend fun Guild.retrieveThreadChannelOrNull(id: Long): ThreadChannel? {
    return retrieveThreadChannelOrNull_(id = id)
}
