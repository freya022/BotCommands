@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import dev.freya02.botcommands.jda.ktx.coroutines.await
import net.dv8tion.jda.api.exceptions.ErrorHandler
import net.dv8tion.jda.api.requests.ErrorResponse
import net.dv8tion.jda.api.requests.RestAction

import dev.freya02.botcommands.jda.ktx.requests.awaitUnit as awaitUnit_
import dev.freya02.botcommands.jda.ktx.requests.awaitNull as awaitNull_
import dev.freya02.botcommands.jda.ktx.requests.queueIgnoring as queueIgnoring_
import dev.freya02.botcommands.jda.ktx.requests.awaitOrNullOn as awaitOrNullOn_
import dev.freya02.botcommands.jda.ktx.requests.awaitCatching as awaitCatching_

/**
 * Awaits the completion of this RestAction.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.awaitUnit\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.awaitUnit"
)
suspend fun RestAction<*>.awaitUnit(): Unit {
    return awaitUnit_()
}

/**
 * Awaits the completion of this RestAction and returns `null`.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.awaitNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.awaitNull"
)
suspend fun <R> RestAction<*>.awaitNull(): R? {
    return awaitNull_()
}

/**
 * Queues this REST action while ignoring the provided error responses.
 *
 * Any other error will be handled using the [default failure consumer][RestAction.setDefaultFailure].
 *
 * @see ErrorHandler
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.queueIgnoring\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.queueIgnoring"
)
fun RestAction<*>.queueIgnoring(ignored: ErrorResponse, vararg errorResponses: ErrorResponse): Unit {
    return queueIgnoring_(ignored = ignored, errorResponses = errorResponses)
}

/**
 * Awaits the completion of this RestAction,
 * returns `null` if one of the provided error responses was thrown.
 *
 * Any other exception or error response occurs will be thrown.
 *
 * @see runIgnoringResponseOrNull
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.awaitOrNullOn\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.awaitOrNullOn"
)
suspend fun <R> RestAction<R>.awaitOrNullOn(ignored: ErrorResponse, vararg errorResponses: ErrorResponse): R? {
    return awaitOrNullOn_(ignored = ignored, errorResponses = errorResponses)
}

/**
 * Awaits the completion of this RestAction and wraps it in a Result.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.awaitCatching\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.awaitCatching"
)
suspend fun <R> RestAction<R>.awaitCatching(): RestResult<R> {
    return awaitCatching_()
}
