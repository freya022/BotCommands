@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

typealias InvalidChannelTypeException = dev.freya02.botcommands.jda.ktx.retrieve.InvalidChannelTypeException
