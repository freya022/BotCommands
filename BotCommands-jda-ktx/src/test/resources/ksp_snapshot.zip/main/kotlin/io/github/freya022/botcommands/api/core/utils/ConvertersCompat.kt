@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.utils.messages.MessageCreateData
import net.dv8tion.jda.api.utils.messages.MessageEditData

import dev.freya02.botcommands.jda.ktx.messages.toEditData as toEditData_
import dev.freya02.botcommands.jda.ktx.messages.toCreateData as toCreateData_

/**
 * @see MessageEditData.fromCreateData
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.toEditData\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.toEditData"
)
fun MessageCreateData.toEditData(): MessageEditData {
    return toEditData_()
}

/**
 * @see MessageCreateData.fromEditData
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.toCreateData\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.toCreateData"
)
fun MessageEditData.toCreateData(): MessageCreateData {
    return toCreateData_()
}
