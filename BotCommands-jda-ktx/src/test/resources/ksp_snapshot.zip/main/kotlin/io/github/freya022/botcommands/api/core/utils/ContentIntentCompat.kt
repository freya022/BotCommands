@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.internal.entities.ReceivedMessage

import dev.freya02.botcommands.jda.ktx.messages.suppressContentWarning as suppressContentWarning_

/**
 * Temporarily suppresses message content intent warnings
 *
 * **Note:** This applies to all threads while the current code is inside this function
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.suppressContentWarning\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.suppressContentWarning"
)
inline fun <R> suppressContentWarning(block: Function0<R>): R {
    return suppressContentWarning_(block = block)
}
