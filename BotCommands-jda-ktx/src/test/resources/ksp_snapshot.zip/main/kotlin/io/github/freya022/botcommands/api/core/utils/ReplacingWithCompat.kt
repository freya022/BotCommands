@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.entities.Message
import net.dv8tion.jda.api.interactions.InteractionHook
import net.dv8tion.jda.api.requests.restaction.WebhookMessageEditAction
import net.dv8tion.jda.api.utils.messages.MessageCreateData
import net.dv8tion.jda.api.utils.messages.MessageEditData

import dev.freya02.botcommands.jda.ktx.messages.replaceWith as replaceWith_

/**
 * @see InteractionHook.editOriginal
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.replaceWith\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.replaceWith"
)
fun InteractionHook.replaceWith(data: MessageEditData): WebhookMessageEditAction<Message> {
    return replaceWith_(data = data)
}

/**
 * @see InteractionHook.editOriginal
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.replaceWith\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.replaceWith"
)
fun InteractionHook.replaceWith(data: MessageCreateData): WebhookMessageEditAction<Message> {
    return replaceWith_(data = data)
}

/**
 * @see InteractionHook.editOriginal
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.replaceWith\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.replaceWith"
)
fun InteractionHook.replaceWith(content: String): WebhookMessageEditAction<Message> {
    return replaceWith_(content = content)
}
