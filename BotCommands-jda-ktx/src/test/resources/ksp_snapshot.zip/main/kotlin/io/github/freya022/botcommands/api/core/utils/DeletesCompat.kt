@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import dev.freya02.botcommands.jda.ktx.durations.delay
import net.dv8tion.jda.api.entities.Message
import net.dv8tion.jda.api.interactions.InteractionHook
import net.dv8tion.jda.api.requests.RestAction
import kotlin.time.Duration

import dev.freya02.botcommands.jda.ktx.messages.deleteDelayed as deleteDelayed_

/**
 * Deletes the original message using the hook after the specified delay.
 *
 * **Note:** This delays the rest action by the given delay.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.deleteDelayed\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.deleteDelayed"
)
fun <R> RestAction<R>.deleteDelayed(hook: InteractionHook, delay: Duration?): RestAction<R> {
    return deleteDelayed_(hook = hook, delay = delay)
}

/**
 * Deletes the original message using the hook after the specified delay.
 *
 * **Note:** This delays the rest action by the given delay.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.deleteDelayed\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.deleteDelayed"
)
fun RestAction<InteractionHook>.deleteDelayed(delay: Duration?): RestAction<InteractionHook> {
    return deleteDelayed_(delay = delay)
}

/**
 * Deletes the message after the specified delay.
 *
 * **Note:** This delays the rest action by the given delay.
 */
@JvmName(name = "deleteDelayedMessage")
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.deleteDelayed\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.deleteDelayed"
)
fun RestAction<Message>.deleteDelayed(delay: Duration?): RestAction<Message> {
    return deleteDelayed_(delay = delay)
}
