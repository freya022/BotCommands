@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.entities.Message
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel
import net.dv8tion.jda.api.interactions.InteractionHook
import net.dv8tion.jda.api.interactions.callbacks.IReplyCallback
import net.dv8tion.jda.api.requests.restaction.MessageCreateAction
import net.dv8tion.jda.api.requests.restaction.WebhookMessageCreateAction
import net.dv8tion.jda.api.requests.restaction.interactions.ReplyCallbackAction
import net.dv8tion.jda.api.utils.messages.MessageCreateData

import dev.freya02.botcommands.jda.ktx.messages.send as send_

/**
 * @see IReplyCallback.reply
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.send\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.send"
)
fun MessageCreateData.send(callback: IReplyCallback, ephemeral: Boolean): ReplyCallbackAction {
    return send_(callback = callback, ephemeral = ephemeral)
}

/**
 * @see InteractionHook.sendMessage
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.send\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.send"
)
fun MessageCreateData.send(hook: InteractionHook, ephemeral: Boolean): WebhookMessageCreateAction<Message> {
    return send_(hook = hook, ephemeral = ephemeral)
}

/**
 * @see MessageChannel.sendMessage
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.send\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.messages.send"
)
fun MessageCreateData.send(channel: MessageChannel): MessageCreateAction {
    return send_(channel = channel)
}
