@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import dev.freya02.botcommands.jda.ktx.IgnoreForMatch
import dev.freya02.botcommands.jda.ktx.coroutines.await
import dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponseOrNull
import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.entities.Entitlement
import net.dv8tion.jda.api.entities.User
import net.dv8tion.jda.api.entities.Webhook
import net.dv8tion.jda.api.entities.sticker.StickerSnowflake
import net.dv8tion.jda.api.entities.sticker.StickerUnion
import net.dv8tion.jda.api.requests.ErrorResponse

import dev.freya02.botcommands.jda.ktx.retrieve.retrieveUserByIdOrNull as retrieveUserByIdOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveStickerOrNull as retrieveStickerOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveEntitlementByIdOrNull as retrieveEntitlementByIdOrNull_
import dev.freya02.botcommands.jda.ktx.retrieve.retrieveWebhookByIdOrNull as retrieveWebhookByIdOrNull_

/**
 * Retrieves a [User] with the provided ID.
 *
 * Throws the same exceptions as [JDA.retrieveUserById], minus [ErrorResponse.UNKNOWN_USER].
 *
 * @param userId   ID of the user to retrieve
 * @param useCache Whether this should rely on the cache, set to `false` to always make a request.
 *
 * @see JDA.retrieveUserById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveUserByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveUserByIdOrNull"
)
suspend fun JDA.retrieveUserByIdOrNull(userId: String, useCache: Boolean): User? {
    return retrieveUserByIdOrNull_(userId = userId, useCache = useCache)
}

/**
 * Retrieves a [User] with the provided ID.
 *
 * Throws the same exceptions as [JDA.retrieveUserById], minus [ErrorResponse.UNKNOWN_USER].
 *
 * @param userId   ID of the user to retrieve
 * @param useCache Whether this should rely on the cache, set to `false` to always make a request.
 *
 * @see JDA.retrieveUserById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveUserByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveUserByIdOrNull"
)
suspend fun JDA.retrieveUserByIdOrNull(userId: Long, useCache: Boolean): User? {
    return retrieveUserByIdOrNull_(userId = userId, useCache = useCache)
}

/**
 * Retrieves a sticker from the provided ID, see [JDA.retrieveSticker] for more details.
 *
 * Throws the same exceptions as [JDA.retrieveSticker], minus [ErrorResponse.UNKNOWN_STICKER].
 *
 * @see JDA.retrieveSticker
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveStickerOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveStickerOrNull"
)
suspend fun JDA.retrieveStickerOrNull(sticker: StickerSnowflake): StickerUnion? {
    return retrieveStickerOrNull_(sticker = sticker)
}

/**
 * Retrieves an [Entitlement] from the provided ID, see [JDA.retrieveEntitlementById] for more details.
 *
 * Throws the same exceptions as [JDA.retrieveEntitlementById], minus [ErrorResponse.UNKNOWN_ENTITLEMENT].
 *
 * @see JDA.retrieveEntitlementById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveEntitlementByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveEntitlementByIdOrNull"
)
suspend fun JDA.retrieveEntitlementByIdOrNull(entitlementId: String): Entitlement? {
    return retrieveEntitlementByIdOrNull_(entitlementId = entitlementId)
}

/**
 * Retrieves an [Entitlement] from the provided ID, see [JDA.retrieveEntitlementById] for more details.
 *
 * Throws the same exceptions as [JDA.retrieveEntitlementById], minus [ErrorResponse.UNKNOWN_ENTITLEMENT].
 *
 * @see JDA.retrieveEntitlementById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveEntitlementByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveEntitlementByIdOrNull"
)
suspend fun JDA.retrieveEntitlementByIdOrNull(entitlementId: Long): Entitlement? {
    return retrieveEntitlementByIdOrNull_(entitlementId = entitlementId)
}

/**
 * Retrieves a [Webhook] from the provided ID, see [JDA.retrieveWebhookById] for more details.
 *
 * Throws the same exceptions as [JDA.retrieveWebhookById], minus [ErrorResponse.UNKNOWN_WEBHOOK].
 *
 * @see JDA.retrieveWebhookById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveWebhookByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveWebhookByIdOrNull"
)
suspend fun JDA.retrieveWebhookByIdOrNull(webhookId: String): Webhook? {
    return retrieveWebhookByIdOrNull_(webhookId = webhookId)
}

/**
 * Retrieves a [Webhook] from the provided ID, see [JDA.retrieveWebhookById] for more details.
 *
 * Throws the same exceptions as [JDA.retrieveWebhookById], minus [ErrorResponse.UNKNOWN_WEBHOOK].
 *
 * @see JDA.retrieveWebhookById
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.retrieveWebhookByIdOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.retrieve.retrieveWebhookByIdOrNull"
)
suspend fun JDA.retrieveWebhookByIdOrNull(webhookId: Long): Webhook? {
    return retrieveWebhookByIdOrNull_(webhookId = webhookId)
}
