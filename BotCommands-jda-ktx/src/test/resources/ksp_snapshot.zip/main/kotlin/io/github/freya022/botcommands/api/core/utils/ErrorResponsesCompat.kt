@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.exceptions.ErrorResponseException
import net.dv8tion.jda.api.requests.ErrorResponse
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.InvocationKind
import kotlin.contracts.contract

import dev.freya02.botcommands.jda.ktx.requests.runCatchingResponse as runCatchingResponse_
import dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponse as runIgnoringResponse_
import dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponseOrNull as runIgnoringResponseOrNull_

/**
 * Encapsulates the result of the specified function [block] and dismisses [error responses][ErrorResponse]
 * that corresponds to an ignored response, making the [Result] a success.
 *
 * @see runIgnoringResponse
 * @see runIgnoringResponseOrNull
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.runCatchingResponse\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.runCatchingResponse"
)
inline fun <R> runCatchingResponse(ignored: ErrorResponse, vararg ignoredResponses: ErrorResponse, block: Function0<R>): RestResult<R> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return runCatchingResponse_(ignored = ignored, ignoredResponses = ignoredResponses, block = block)
}

/**
 * Runs the specified function [block] and dismisses [error responses][ErrorResponse]
 * that corresponds to an ignored response.
 *
 * Any other exception is still thrown.
 *
 * @see ignore
 * @see runIgnoringResponseOrNull
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.runIgnoringResponse\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponse"
)
inline fun runIgnoringResponse(ignored: ErrorResponse, vararg ignoredResponses: ErrorResponse, block: Function0<Unit>): Unit {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return runIgnoringResponse_(ignored = ignored, ignoredResponses = ignoredResponses, block = block)
}

/**
 * Runs the specified function [block] and returns `null` on [error responses][ErrorResponse]
 * that corresponds to an ignored response.
 *
 * Any other exception is still thrown.
 *
 * @see ignore
 * @see runIgnoringResponse
 * @see awaitOrNullOn
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.runIgnoringResponseOrNull\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.runIgnoringResponseOrNull"
)
inline fun <R> runIgnoringResponseOrNull(ignored: ErrorResponse, vararg ignoredResponses: ErrorResponse, block: Function0<R>): R? {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return runIgnoringResponseOrNull_(ignored = ignored, ignoredResponses = ignoredResponses, block = block)
}
