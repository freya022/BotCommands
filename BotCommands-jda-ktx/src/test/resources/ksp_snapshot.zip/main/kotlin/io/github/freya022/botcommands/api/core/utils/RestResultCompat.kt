@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.exceptions.ErrorResponseException
import net.dv8tion.jda.api.requests.ErrorResponse
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.InvocationKind
import kotlin.contracts.contract
import kotlin.reflect.KClass

import dev.freya02.botcommands.jda.ktx.requests.onErrorResponseException as onErrorResponseException_
import dev.freya02.botcommands.jda.ktx.requests.onErrorResponse as onErrorResponse_
import dev.freya02.botcommands.jda.ktx.requests.ignore as ignore_
import dev.freya02.botcommands.jda.ktx.requests.recover as recover_
import dev.freya02.botcommands.jda.ktx.requests.handle as handle_
import dev.freya02.botcommands.jda.ktx.requests.runCatchingRest as runCatchingRest_

typealias RestResult<T> = dev.freya02.botcommands.jda.ktx.requests.RestResult<T>

/**
 * Runs the given [block] if the result is an [ErrorResponseException].
 *
 * This does not clear the exception.
 *
 * Returns the original `RestResult` unchanged.
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.onErrorResponseException\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.onErrorResponseException"
)
inline fun <T> RestResult<T>.onErrorResponseException(block: Function1<ErrorResponseException, Unit>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return onErrorResponseException_(block = block)
}

/**
 * Runs the given [block] if the result is an [error response][ErrorResponse].
 *
 * This does not clear the exception.
 *
 * Returns the original `RestResult` unchanged.
 *
 * @see ignore
 * @see handle
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.onErrorResponse\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.onErrorResponse"
)
inline fun <T> RestResult<T>.onErrorResponse(block: Function1<ErrorResponse, Unit>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return onErrorResponse_(block = block)
}

/**
 * Runs the given [block] if the result is the specified [error response][ErrorResponse].
 *
 * This does not clear the exception.
 *
 * Returns the original `RestResult` unchanged.
 *
 * @see ignore
 * @see handle
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.onErrorResponse\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.onErrorResponse"
)
inline fun <T> RestResult<T>.onErrorResponse(error: ErrorResponse, block: Function1<ErrorResponseException, Unit>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return onErrorResponse_(error = error, block = block)
}

/**
 * Dismisses the encapsulated exception if it corresponds to the [predicate].
 *
 * Allows for [orThrow][RestResult.orThrow] to be used on failures without throwing,
 * but does not allow using functions returning values.
 *
 * Exceptions thrown in [predicate] are returned in a new [RestResult].
 *
 * @see handle
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ignore\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.ignore"
)
inline fun <T> RestResult<T>.ignore(predicate: Function1<Throwable, Boolean>): RestResult<T> {
    contract {
        callsInPlace(predicate, InvocationKind.AT_MOST_ONCE)
    }

    return ignore_(predicate = predicate)
}

/**
 * Dismisses the encapsulated [error response][ErrorResponse]
 * if it corresponds to an ignored response.
 *
 * Allows for [orThrow][RestResult.orThrow] to be used on failures without throwing,
 * but does not allow using functions returning values.
 *
 * @see handle
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ignore\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.ignore"
)
fun <T> RestResult<T>.ignore(ignored: ErrorResponse, vararg responses: ErrorResponse): RestResult<T> {
    return ignore_(ignored = ignored, responses = responses)
}

/**
 * Dismisses the encapsulated exception
 * if it corresponds to an ignored exception.
 *
 * Allows for [orThrow][RestResult.orThrow] to be used on failures without throwing,
 * but does not allow using functions returning values.
 *
 * @see handle
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ignore\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.ignore"
)
fun <T> RestResult<T>.ignore(ignored: KClass<out Throwable>, vararg types: KClass<out Throwable>): RestResult<T> {
    return ignore_(ignored = ignored, types = types)
}

/**
 * Maps the encapsulated exception using the given [block]
 * if it corresponds to the [predicate].
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.recover\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.recover"
)
inline fun <T : R, R> RestResult<T>.recover(predicate: Function1<Throwable, Boolean>, block: Function1<Throwable, R>): RestResult<R> {
    contract {
        callsInPlace(predicate, InvocationKind.AT_MOST_ONCE)
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return recover_(predicate = predicate, block = block)
}

/**
 * Maps the encapsulated exception using the given [block]
 * if it corresponds to an ignored response.
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.recover\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.recover"
)
inline fun <T : R, R> RestResult<T>.recover(response: ErrorResponse, vararg responses: ErrorResponse, block: Function1<ErrorResponseException, R>): RestResult<R> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return recover_(response = response, responses = responses, block = block)
}

/**
 * Maps the encapsulated exception using the given [block]
 * if it corresponds to an ignored exception type.
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.recover\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.recover"
)
inline fun <T : R, R> RestResult<T>.recover(type: KClass<out Throwable>, vararg types: KClass<out Throwable>, block: Function1<Throwable, R>): RestResult<R> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return recover_(type = type, types = types, block = block)
}

/**
 * Dismisses the encapsulated exception and runs the given [block]
 * if it matches the [predicate].
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * Returns a new [RestResult] with the ignored exception, or itself if it didn't match.
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.handle\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.handle"
)
inline fun <T> RestResult<T>.handle(predicate: Function1<Throwable, Boolean>, block: Function1<Throwable, Unit>): RestResult<T> {
    contract {
        callsInPlace(predicate, InvocationKind.UNKNOWN)
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return handle_(predicate = predicate, block = block)
}

/**
 * Dismisses the encapsulated exception and runs the given [block]
 * if it corresponds to an ignored response.
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * Returns a new [RestResult] with the ignored exception, or itself if it didn't match.
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.handle\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.handle"
)
inline fun <T> RestResult<T>.handle(type: ErrorResponse, vararg responses: ErrorResponse, block: Function1<ErrorResponseException, Unit>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return handle_(type = type, responses = responses, block = block)
}

/**
 * Dismisses the encapsulated exception and runs the given [block]
 * if it corresponds to an ignored exception type.
 *
 * Any thrown exception will be encapsulated in a new [RestResult].
 *
 * Returns a new [RestResult] with the ignored exception, or itself if it didn't match.
 *
 * @see ignore
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.handle\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.handle"
)
inline fun <T> RestResult<T>.handle(type: KClass<out Throwable>, vararg types: KClass<out Throwable>, block: Function1<Throwable, Unit>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return handle_(type = type, types = types, block = block)
}

/**
 * Calls the specified function [block] and returns its encapsulated result if invocation was successful,
 * catching any [Throwable] exception that was thrown from the [block] function execution
 * and encapsulating it as a failure.
 */
@OptIn(ExperimentalContracts::class)
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.runCatchingRest\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.requests.runCatchingRest"
)
inline fun <T> runCatchingRest(block: Function0<T>): RestResult<T> {
    contract {
        callsInPlace(block, InvocationKind.AT_MOST_ONCE)
    }

    return runCatchingRest_(block = block)
}
