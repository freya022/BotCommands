@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.interactions.components.selections.SelectMenu

import dev.freya02.botcommands.jda.ktx.ranges.setRequiredRange as setRequiredRange_

/**
 * The minimum and maximum amount of values a user can select.
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.setRequiredRange\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.ranges.setRequiredRange"
)
fun <B : SelectMenu.Builder<*, B>> SelectMenu.Builder<*, B>.setRequiredRange(range: IntRange): B {
    return setRequiredRange_(range = range)
}
