@file:Suppress("unused")

package io.github.freya022.botcommands.api.core.utils

import net.dv8tion.jda.api.JDA
import net.dv8tion.jda.api.entities.BulkBanResponse
import net.dv8tion.jda.api.entities.Guild
import net.dv8tion.jda.api.entities.Member
import net.dv8tion.jda.api.entities.UserSnowflake
import net.dv8tion.jda.api.events.GenericEvent
import net.dv8tion.jda.api.requests.RestAction
import net.dv8tion.jda.api.requests.restaction.AuditableRestAction
import net.dv8tion.jda.api.utils.FileUpload
import net.dv8tion.jda.api.utils.Once
import net.dv8tion.jda.api.utils.TimeFormat
import net.dv8tion.jda.api.utils.Timestamp
import net.dv8tion.jda.api.utils.concurrent.Task
import net.dv8tion.jda.api.utils.messages.MessagePollBuilder
import net.dv8tion.jda.internal.utils.concurrent.task.GatewayTask
import okhttp3.MediaType
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.time.Duration
import kotlin.time.toJavaDuration

import dev.freya02.botcommands.jda.ktx.durations.delay as delay_
import dev.freya02.botcommands.jda.ktx.durations.timeout as timeout_
import dev.freya02.botcommands.jda.ktx.durations.awaitShutdown as awaitShutdown_
import dev.freya02.botcommands.jda.ktx.durations.timeoutFor as timeoutFor_
import dev.freya02.botcommands.jda.ktx.durations.ban as ban_
import dev.freya02.botcommands.jda.ktx.durations.after as after_
import dev.freya02.botcommands.jda.ktx.durations.before as before_
import dev.freya02.botcommands.jda.ktx.durations.plus as plus_
import dev.freya02.botcommands.jda.ktx.durations.minus as minus_
import dev.freya02.botcommands.jda.ktx.durations.setTimeout as setTimeout_

/**
 * @see RestAction.delay
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.delay\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.delay"
)
fun <T> RestAction<T>.delay(duration: Duration): RestAction<T> {
    return delay_(duration = duration)
}

/**
 * @see RestAction.delay
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.delay\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.delay"
)
fun <T> RestAction<T>.delay(duration: Duration, scheduler: ScheduledExecutorService): RestAction<T> {
    return delay_(duration = duration, scheduler = scheduler)
}

/**
 * @see RestAction.timeout
 */
@Suppress(names = ["UNCHECKED_CAST"])
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.timeout\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.timeout"
)
fun <T : RestAction<*>> T.timeout(duration: Duration): T {
    return timeout_(duration = duration)
}

/**
 * @see JDA.awaitShutdown
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.awaitShutdown\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.awaitShutdown"
)
fun JDA.awaitShutdown(timeout: Duration): Boolean {
    return awaitShutdown_(timeout = timeout)
}

/**
 * @see Guild.timeoutFor
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.timeoutFor\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.timeoutFor"
)
fun Guild.timeoutFor(user: UserSnowflake, duration: Duration): AuditableRestAction<Void> {
    return timeoutFor_(user = user, duration = duration)
}

/**
 * @see Member.timeoutFor
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.timeoutFor\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.timeoutFor"
)
fun Member.timeoutFor(duration: Duration): AuditableRestAction<Void> {
    return timeoutFor_(duration = duration)
}

/**
 * @see Member.ban
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ban\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.ban"
)
fun Member.ban(deletionTimeframe: Duration): AuditableRestAction<Void> {
    return ban_(deletionTimeframe = deletionTimeframe)
}

/**
 * @see Guild.ban
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ban\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.ban"
)
fun Guild.ban(user: UserSnowflake, deletionTimeframe: Duration): AuditableRestAction<Void> {
    return ban_(user = user, deletionTimeframe = deletionTimeframe)
}

/**
 * See [bulk ban from JDA](https://docs.jda.wiki/net/dv8tion/jda/api/entities/Guild.html#ban(java.util.Collection,java.time.Duration))
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.ban\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.ban"
)
fun Guild.ban(users: Collection<UserSnowflake>, duration: Duration): AuditableRestAction<BulkBanResponse> {
    return ban_(users = users, duration = duration)
}

/**
 * @see TimeFormat.after
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.after\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.after"
)
fun TimeFormat.after(duration: Duration): Timestamp {
    return after_(duration = duration)
}

/**
 * @see TimeFormat.before
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.before\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.before"
)
fun TimeFormat.before(duration: Duration): Timestamp {
    return before_(duration = duration)
}

/**
 * @see Timestamp.plus
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.plus\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.plus"
)
operator fun Timestamp.plus(duration: Duration): Timestamp {
    return plus_(duration = duration)
}

/**
 * @see Timestamp.minus
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.minus\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.minus"
)
operator fun Timestamp.minus(duration: Duration): Timestamp {
    return minus_(duration = duration)
}

/**
 * @see Task.setTimeout
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.setTimeout\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.setTimeout"
)
fun <T> Task<T>.setTimeout(duration: Duration): Task<T> {
    return setTimeout_(duration = duration)
}

/**
 * @see GatewayTask.setTimeout
 */
@Deprecated(
    message = "Moved to the BotCommands-jda-ktx module\n" +
              "You can find & replace:\n" +
              "Find: io.github.freya022.botcommands.api.core.utils.setTimeout\n" +
              "Replace: dev.freya02.botcommands.jda.ktx.durations.setTimeout"
)
fun <T> GatewayTask<T>.setTimeout(duration: Duration): Task<T> {
    return setTimeout_(duration = duration)
}
